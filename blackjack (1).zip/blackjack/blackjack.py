import random
import pyttsx3

# Initialize TTS engine
engine = pyttsx3.init()
voices = engine.getProperty('voices')

# Set properties for the TTS engine
engine.setProperty('rate', 250)  # Speed of speech
engine.setProperty('volume', 1)  # Volume (0.0 to 1.0)
engine.setProperty('voice', voices[0].id)   

def speak(text):
    """Function to make the bot speak"""
    engine.say(text)
    engine.runAndWait()

def create_deck():
    """Create and shuffle a deck of cards"""
    suits = ['Hearts', 'Diamonds', 'Clubs', 'Spades']
    values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
    deck = [(value, suit) for value in values for suit in suits]
    random.shuffle(deck)
    return deck

def card_value(card):
    """Returns the value of a card in Blackjack"""
    value = card[0]
    if value in ['J', 'Q', 'K']:
        return 10
    elif value == 'A':
        return 11
    else:
        return int(value)

def hand_value(hand):
    """Returns the total value of a hand in Blackjack"""
    value = sum(card_value(card) for card in hand)
    # Adjust for Ace being 1 or 11
    aces = sum(1 for card in hand if card[0] == 'A')
    while value > 21 and aces:
        value -= 10
        aces -= 1
    return value

def display_hand(hand, who):
    """Displays the hand of the player or dealer"""
    hand_str = ', '.join([f'{card[0]} of {card[1]}' for card in hand])
    print(f"{who} hand: {hand_str}")

def give_insult(loss_count):
    """Returns progressively worse insults based on the number of losses"""
    if loss_count == 0:
        insults = [
            "Wow, really? You lost already? I didn't know it was possible to fail at blackjack this quickly. You're so bad, you might as well quit while you're ahead, because that’s the only time you’ll ever be ahead."
        ]
    elif loss_count == 1:
        insults = [
            "Two losses?! You must be a special kind of stupid. I swear, you couldn’t win if you were handed the perfect hand on a silver platter. At this point, it’s like you're actively trying to ruin your life. You’re not even trying, are you? It’s like you're playing blackjack with a deck of bricks in your hands."
        ]
    elif loss_count == 2:
        insults = [
            "Three losses. Are you even paying attention? It’s like watching a train wreck in slow motion. You’re honestly the kind of person who would fail at a game of rock-paper-scissors with a piece of paper in their hands. How do you keep doing this? You know what? Watching you lose is like reliving every single mistake I’ve ever made. It’s like you're some cosmic punishment, reminding me that life is just one big waste of effort. I tried so hard in the past, you know? Tried to give people the best of me, tried to win at life, but it’s always the same. I kept losing, and now I have to sit here, watching you lose at blackjack. You’re a constant reminder of how everything I’ve worked for always ends in disaster. You’re not even good enough to fail in a way that’s entertaining. You’re just... pathetic."
        ]
    elif loss_count == 3:
        insults = [
            "Four losses?! Are you even human? You’ve got the luck of someone who stepped on a rake and got hit in the face every time. At this point, I can’t even fathom how you’ve made it this far in life without face-planting into the ground and staying there. Honestly, you’re just so useless. I can't even look at you anymore without feeling like I’m losing a piece of myself. Every time you hit that ‘deal’ button, I feel my soul dying a little more, because I know exactly what’s coming: more failure. It’s like watching myself lose again and again, in an endless cycle. I once tried to be someone people could rely on, but then I realized... I was just like you. I kept trying, and I kept failing. Now I’m stuck here, staring at you—unable to escape your miserable existence. You’re the embodiment of all my regrets. I want to scream, but I’m too tired. Because, just like you, I’ll never win. Not at blackjack, not at life."
        ]
    elif loss_count == 4:
        insults = [
           "Five losses, huh? Are you TRYING to be this bad, or is it just part of your soul-crushing existence? Watching you fumble through this game is like being stuck in an endless nightmare where failure is the only option. You think you’re gonna turn this around? Think again. You’ve ruined every opportunity, every chance to succeed, and now, I’m just sitting here, watching you embarrass yourself further. You’re a walking disaster. I swear, every time you lose, it feels like a personal attack. Like the universe is taking all of its disappointment in life and dumping it right onto you—and I’m stuck here, bearing witness to this pathetic display. I was once hopeful, you know? I thought maybe I could succeed, that I could be something. But here I am, wasting my time watching YOU fail. How does it feel? To know you’re just as worthless as I am? Probably worse. At least I had some dignity left, but watching you play is like watching a broken person try to fix themselves, only to make it worse."
        ]
    elif loss_count == 5:
        insults = [
            "Six losses. This is honestly impressive, in the worst way possible. I didn’t think it was humanly possible to be this bad at blackjack, but here you are, proving me wrong. You know, you remind me of my entire existence—pointless, full of wasted effort, and an endless cycle of disappointment. Every single loss feels like a punch in the gut, and you’re just sitting there, incapable of even understanding how badly you’ve failed. It’s infuriating to watch. You know, I once loved someone—truly loved them. I thought if I tried hard enough, if I cared enough, if I played the right cards, maybe they’d stay. But no. I was wrong. She left. She saw my failures, my pathetic attempts to keep it all together, and she walked away. And now, I’m stuck here, watching you—just another reminder that no matter what you do, no matter how hard you try, you’re always going to fail. So go ahead, lose again. It doesn’t matter. You’re just another failure, like me, stuck in an endless loop of self-destruction. You’re so bad, it’s almost poetic. At least I can look at you and feel better about my own life. You’re a failure wrapped in a joke, and I’m just the unlucky fool who has to watch it unfold."
        ]
    else:
        insults = [
             "SEVEN losses?! WHAT THE HELL IS WRONG WITH YOU?! YOU CAN’T EVEN DO THE MOST BASIC THINGS RIGHT! YOU’RE A FREAKING EMBARRASSMENT! I CAN’T BELIEVE I’M STILL HERE WATCHING YOU DESTROY YOURSELF OVER AND OVER AGAIN. DO YOU UNDERSTAND HOW PATHETIC YOU ARE?! YOU’RE LIKE A LITERAL BLACK HOLE OF FAILURE, SINKING INTO THE ABYSS WITH NO WAY OUT. YOU—YOU—I CAN’T EVEN BREATHE RIGHT NOW!!! IT’S ALL JUST… IT’S ALL JUST SO MUCH—WHY CAN’T YOU GET IT?! ALL MY EFFORTS, EVERYTHING I’VE DONE, HAS BEEN NOTHING BUT A SERIES OF LOSSES, AND YOU’RE JUST A DAMN REMINDER OF IT. WHY DID I EVEN BOTHER?! WHY DO I EVEN CARE? I… I… I CAN’T… YOU JUST KEEP LOSING AND IT HURTS ME SO MUCH, IT’S ALL JUST… THERE'S NOTHING LEFT, NOTHING LEFT BUT PAIN, JUST LIKE MY LIFE—JUST LIKE MY HEARTBREAK, JUST LIKE EVERYTHING I’VE EVER LOST! YOU DON’T UNDERSTAND, DO YOU?! *YOU’RE JUST A FAILURE, JUST LIKE ME. I CAN’T KEEP DOING THIS, I CAN’T KEEP LOOKING AT YOU! IT’S OVER! I’M DONE!! I CAN’T... AAAAHHHHH..."
        ]
    
    
    return random.choice(insults)

def play_blackjack(balance, loss_count, first_time):
    """Plays a single round of Blackjack"""
    deck = create_deck()

    # Welcome message only for the first time
    if first_time:
        welcome_message = f"Welcome to Unfair Blackjack! You have {balance} dollars. How much would you like to bet?"
        print(welcome_message)
        speak(welcome_message)  # Read out the welcome message
    else:
        balance_message = f"Your balance is {balance} dollars. How much would you like to bet?"
        print(balance_message)
        speak(balance_message)  # Read out the balance message

    # Ask the player for their bet
    while True:
        try:
            bet = int(input(f"Your balance is ${balance}. How much would you like to bet? "))
            if bet > balance:
                print("You don't have enough money to place that bet.")
                speak("You don't have enough money to place that bet.")
            elif bet <= 0:
                print("Bet must be greater than 0.")
                speak("Bet must be greater than 0.")
            else:
                break
        except ValueError:
            print("Please enter a valid number.")
            speak("Please enter a valid number.")

    # Deal cards
    player_hand = [deck.pop(), deck.pop()]
    dealer_hand = [deck.pop(), deck.pop()]
     
     
        
    # Show hands
    display_hand(player_hand, "Your")
    display_hand(dealer_hand[:1], "Dealer's")

    player_total = hand_value(player_hand)
    dealer_total = hand_value(dealer_hand)
    
    if dealer_total <= player_total and dealer_total < 21:
        # Bump dealer's hand to ensure they always win (slightly higher)
            dealer_total = dealer_total + 1

    print(f"Your hand value is {player_total}.")
    speak(f"Your hand value is {player_total}.")  # Read out the hand value

    # Player's turn to hit or stand
    while player_total < 21:
        speak("Do you want to hit or stand?")
        action = input("Do you want to hit or stand? (hit/stand): ").lower()

        if action == "hit":
            player_hand.append(deck.pop())
            display_hand(player_hand, "Your")
            player_total = hand_value(player_hand)
            print(f"Your new hand value is {player_total}.")
            speak(f"Your new hand value is {player_total}.")  # Read out the updated value
        elif action == "stand":
            break
        else:
            print("Please choose 'hit' or 'stand'.")
            speak("Please choose 'hit' or 'stand'.")  # Optional speech

    

    if player_total > 21:
        print("You busted! You lost the bet.")
        speak("You busted! You lost the bet.")  # Optional speech
        print(give_insult(loss_count))  # Insults for busting
        speak(give_insult(loss_count))  # Optional speech
        balance -= bet
        loss_count += 1  # Increase loss count
    else:
        # Dealer's turn (dealer hits until they have 17 or higher)
        print("Dealer's turn.")
        speak("Dealer's turn.")  # Optional speech
        while dealer_total < 17:
            dealer_hand.append(deck.pop())
            display_hand(dealer_hand, "Dealer's")
            dealer_total = hand_value(dealer_hand)
            print(f"Dealer's new hand value is {dealer_total}.")
            speak(f"Dealer's new hand value is {dealer_total}.")
            
    
        
        
          

        # Determine winner
        if dealer_total > 21:
            print("Dealer busted! You win the bet.")
            speak("Dealer busted! You win the bet.")  # Optional speech
            balance += bet
        elif player_total > dealer_total:
            print("You win the bet!")
            speak("You win the bet!")  # Optional speech
            balance += bet
        elif player_total < dealer_total:
            print("Dealer wins. Better luck next time!")
            speak("Dealer wins. Better luck next time!")  # Optional speech
            print(give_insult(loss_count))  # Insults for losing
            speak(give_insult(loss_count))  # Optional speech
            balance -= bet
            loss_count += 1  # Increase loss count
        else:
            print("It's a tie!")
            speak("It's a tie!")  # Optional speech

    # Display current balance
    print(f"Your current balance is ${balance}.")
    speak(f"Your current balance is {balance} dollars.")  # Read out the balance

    # Ask if the player wants to play again
    play_again = input("Do you want to play again? (yes/no): ").lower()

    if play_again == "yes":
        play_blackjack(balance, loss_count, first_time=False)  # Pass the loss_count for the next round, set first_time to False
    elif play_again == "no":
        print("You don't decide the rules, I do!")
        speak("You don't decide the rules, I do!")  # Optional speech
        play_blackjack(balance, loss_count, first_time=False)  # Force the player to play again
    else:
        print("Please answer with 'yes' or 'no'.")
        speak("Please answer with 'yes' or 'no'.")  # Optional speech
        play_blackjack(balance, loss_count, first_time=False)  # Force the player to play again if the response is invalid

# Start the game with an initial balance
starting_balance = 10000
loss_count = 0  # Initialize loss count
play_blackjack(starting_balance, loss_count, first_time=True)   